

<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('content-title', 'Dashboard'); ?>

<?php $__env->startSection('content'); ?>
    <main class="flex-1 ml-28">
        <div class="bg-blue"> <!-- Hero Section-->
            
            <div class="mx-auto place-content-center h-screen w-9/12 text-slate-900">
                <div class="container w-6/12">
                    <h2 class="my-4 text-2xl font-semibold text-black">Create New Jadwal</h2>
            
                    <?php if(session('success')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('success')); ?>

                        </div>
                    <?php endif; ?>
            
                    <form action="<?php echo e(route('jadwal.store')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="id_guru" class="text-black">Guru:</label>
                            <select name="id_guru" class="form-control">
                                <option value="" disabled selected class="text-gray-500">Select Guru</option>
                                <?php $__currentLoopData = $gurus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $guru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($guru->id); ?>"><?php echo e($guru->nama_guru); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
            
                        <div class="form-group">
                            <label for="id_student" class="text-black">Student:</label>
                            <select name="id_student" class="form-control">
                                <option value="" disabled selected class="text-gray-500">Select Student</option>
                                <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($student->id); ?>"><?php echo e($student->firstName); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
            
                        <div class="form-group">
                            <label for="jadwal" class="text-black">Jadwal:</label>
                            <select name="jadwal" class="form-control" required>
                                <option value="Pagi">Pagi</option>
                                <option value="Siang">Siang</option>
                                <option value="Sore">Sore</option>
                            </select>
                        </div>
                        
            
                        <div class="form-group">
                            <label for="jam_mulai" class="text-black">Jam Mulai:</label>
                            <select name="jam_mulai" class="form-control">
                                <?php for($i = 7; $i < 24; $i++): ?>
                                    <?php for($j = 0; $j < 60; $j += 15): ?>
                                        <option value="<?php echo e(sprintf('%02d:%02d', $i, $j)); ?>"><?php echo e(sprintf('%02d:%02d', $i, $j)); ?></option>
                                    <?php endfor; ?>
                                <?php endfor; ?>
                            </select>
                        </div>
            
                        <div class="form-group">
                            <label for="jam_selesai" class="text-black">Jam Selesai:</label>
                            <select name="jam_selesai" class="form-control">
                                <?php for($i = 7; $i < 24; $i++): ?>
                                    <?php for($j = 0; $j < 60; $j += 15): ?>
                                        <option value="<?php echo e(sprintf('%02d:%02d', $i, $j)); ?>"><?php echo e(sprintf('%02d:%02d', $i, $j)); ?></option>
                                    <?php endfor; ?>
                                <?php endfor; ?>
                            </select>
                        </div>
            
                        <button type="submit" class="btn btn-primary">Add Jadwal</button>
                    </form>

                    <a href="<?php echo e(route('jadwal.index')); ?>" class="text-blue-500 mt-4">Back</a>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('backpage.admintemplate', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PUTRAKENAKA\Downloads\ExpertLingoNEW1\ExpertLingo\resources\views/backpage/addjadwal.blade.php ENDPATH**/ ?>