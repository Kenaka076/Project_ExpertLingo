

<?php $__env->startSection('title', 'Expertlingo'); ?>

<?php $__env->startSection('content'); ?>

    <section id="app" class="bg-gradient-to-b from-slate-800 via-slate-900 to-slate-900 p-6 text-white">
        <!-- Informasi Kursus -->
        <div class="p-20 grid grid-cols-4 gap-6 ">
            <!-- Detail Kursus -->
            <div>
                <h1 class="text-4xl font-bold mb-4">Kursus</h1>

                <!-- Jenis Kelas -->
                <div class="mb-4">
                    <label for="jenis kelas" class="block text-white text-sm font-medium">Jenis Kelas: </label>
                    <input type="text" id="jenis kelas" name="jenis kelas"
                        class="mt-1 p-2 w-full border rounded-md text-gray-800">
                </div>

                <!-- Tanggal Pelaksanaan -->
                <div class="mb-4">
                    <label for="tanggal pelaksanaan" class="block text-white text-sm font-medium">Tanggal Pelaksanaan:
                    </label>
                    <input type="text" id="tanggal pelaksanaan" name="tanggal pelaksanaan"
                        class="mt-1 p-2 w-full border rounded-md text-gray-800">
                </div>

                <div class="mb-4">
                    <label for="custom-time" class="block text-gray-300 text-sm font-medium">Durasi Waktu
                        Pelaksanaan:</label>
                    <div class="flex">
                        <!-- Hour Selector -->
                        <input type="number" id="hour-selector" min="0" max="23"
                            class="mr-2 p-2 border rounded-md text-gray-800 bg-white" placeholder="Hour">

                        <!-- Minute Selector -->
                        <input type="number" id="minute-selector" min="0" max="59"
                            class="mr-2 p-2 border rounded-md text-gray-800 bg-white" placeholder="Minute">

                        <!-- Second Selector -->
                        <input type="number" id="second-selector" min="0" max="59"
                            class="p-2 border rounded-md text-gray-800 bg-white" placeholder="Second">
                    </div>

                    <!-- Spinner for Custom Time -->
                    <div id="spinner-container"
                        class="absolute inset-y-0 right-0 pr-3 flex items-center pointer-events-none">
                        <div class="spinner-border text-gray-400 hidden" role="status">
                            <span class="sr-only">Loading...</span>
                        </div>
                    </div>
                </div>


                <a href="<?php echo e(route('pilih_guru')); ?>">
                    <button v-if="!courseStarted" @click="startCourse('Basic English')"
                        class="flex justify-center items-center px-4 py-2 bg-blue-500 text-white text-xl 
                                   text-bold rounded-md hover:bg-yellow-500 focus:outline-none focus:shadow-outline">
                        Selanjutnya
                    </button>
                </a>


            </div>


    </section>


<!-- Scripts -->
<script src="js/jquery.min.js"></script> <!-- jQuery for JavaScript plugins -->
<script src="js/jquery.easing.min.js"></script> <!-- jQuery Easing for smooth scrolling between anchors -->
<script src="js/swiper.min.js"></script> <!-- Swiper for image and text sliders -->
<script src="js/jquery.magnific-popup.js"></script> <!-- Magnific Popup for lightboxes -->
<script src="js/scripts.js"></script> <!-- Custom scripts -->

<script src="https://cdn.jsdelivr.net/npm/vue@2.6.14/dist/vue.js"></script>

<script>
    // Add event listeners or Vue.js methods to handle time selection and spinner visibility
    document.getElementById('hour-selector').addEventListener('input', handleTimeSelection);
    document.getElementById('minute-selector').addEventListener('input', handleTimeSelection);
    document.getElementById('second-selector').addEventListener('input', handleTimeSelection);

    function handleTimeSelection() {
        // Show spinner when time is selected
        document.getElementById('spinner-container').classList.remove('hidden');

        // Simulate an asynchronous operation (e.g., API call) with setTimeout
        setTimeout(function() {
            // Hide spinner after a delay (replace this with your actual logic)
            document.getElementById('spinner-container').classList.add('hidden');
        }, 1000); // Adjust the delay as needed


        function redirectToPage() {
            document.getElementById('redirectForm').submit();
        }

    }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Kuliah\Code\Tekweb\Kelompok\ExpertLingo\resources\views/frontpage/kursus.blade.php ENDPATH**/ ?>