<?php $__env->startSection('title', 'Expertlingo'); ?>

<?php $__env->startSection('content'); ?>


    <section>
        <div class="mb-8">
            <h1 class="text-3xl font-semibold mb-4">Pilih Guru</h1>
            <!-- Tabel atau konten lainnya dapat ditambahkan di sini -->
        </div>

        <div class="grid grid-cols-4 gap-8 bg-gray-300 p-2 rounded-md" id="guruGrid">

            <!-- Kotak 1 -->
            <div class="bg-white p-4 rounded-md shadow-md flex flex-col items-center justify-center space-y-4 guru-box" data-guru="1">
                <div class="flex-shrink-0">
                    <img src="https://cdn.pixabay.com/photo/2014/03/25/16/24/female-296990_1280.png" alt="Gambar 1" class="w-12 h-12 object-cover rounded-full">
                </div>
                <div class="text-center">
                    <h2 class="text-lg font-semibold">Mrs. Mela</h2>
                    <p class="text-gray-600">Pendidikan terakhir magister di Universitas Indonesia</p>
                </div>
                <div class="mt-auto">
                    <button class="text-gray-500 hover:text-gray-700 focus:text-gray-700 focus:outline-none">
                        <!-- Icon panah ke bawah dari Heroicons -->
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Kotak 2 -->
            <div class="bg-white p-4 rounded-md shadow-md flex flex-col items-center justify-center space-y-4 guru-box" data-guru="1">
                <div class="flex-shrink-0">
                    <img src="https://cdn.pixabay.com/photo/2014/03/25/16/24/female-296990_1280.png" alt="Gambar 1" class="w-12 h-12 object-cover rounded-full">
                </div>
                <div class="text-center">
                    <h2 class="text-lg font-semibold">Mrs. </h2>
                    <p class="text-gray-600">Pendidikan terakhir magister di Universitas Indonesia</p>
                </div>
                <div class="mt-auto">
                    <button class="text-gray-500 hover:text-gray-700 focus:text-gray-700 focus:outline-none">
                        <!-- Icon panah ke bawah dari Heroicons -->
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Kotak 3 -->
            <div class="bg-white p-4 rounded-md shadow-md flex flex-col items-center justify-center space-y-4 guru-box" data-guru="1">
                <div class="flex-shrink-0">
                    <img src="https://cdn.pixabay.com/photo/2013/07/12/14/36/man-148582_1280.png" alt="Gambar 1" class="w-12 h-12 object-cover rounded-full">
                </div>
                <div class="text-center">
                    <h2 class="text-lg font-semibold">Mr. Eren</h2>
                    <p class="text-gray-600">Pendidikan terakhir magister di Universitas Indonesia</p>
                </div>
                <div class="mt-auto">
                    <button class="text-gray-500 hover:text-gray-700 focus:text-gray-700 focus:outline-none">
                        <!-- Icon panah ke bawah dari Heroicons -->
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <!-- Kotak 4 -->
            <div class="bg-white p-4 rounded-md shadow-md flex flex-col items-center justify-center space-y-4 guru-box" data-guru="1">
                <div class="flex-shrink-0">
                    <img src="https://cdn.pixabay.com/photo/2013/07/12/14/36/man-148582_1280.png" alt="Gambar 1" class="w-12 h-12 object-cover rounded-full">
                </div>
                <div class="text-center">
                    <h2 class="text-lg font-semibold">Mrs. Yodi</h2>
                    <p class="text-gray-600">Pendidikan terakhir magister di Universitas Padjajaran</p>
                </div>
                <div class="mt-auto">
                    <button class="text-gray-500 hover:text-gray-700 focus:text-gray-700 focus:outline-none">
                        <!-- Icon panah ke bawah dari Heroicons -->
                        <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7"></path>
                        </svg>
                    </button>
                </div>
            </div>

            <a href="<?php echo e(route('payment')); ?>">
                <button v-if="!courseStarted" @click="startCourse('Basic English')"
                    class="flex justify-center items-center px-4 py-2 bg-blue-500 text-white text-xl 
                           text-bold rounded-md hover:bg-yellow-500 focus:outline-none focus:shadow-outline">
                    Selanjutnya
                </button>
            </a>

        </div>
    </section>


    <!-- Scripts -->
    <script src="js/jquery.min.js"></script>
    <!-- jQuery for JavaScript plugins -->
    <script src="js/jquery.easing.min.js"></script>
    <!-- jQuery Easing for smooth scrolling between anchors -->
    <script src="js/swiper.min.js"></script>
    <!-- Swiper for image and text sliders -->
    <script src="js/jquery.magnific-popup.js"></script>
    <!-- Magnific Popup for lightboxes -->
    <script src="js/scripts.js"></script>
    <!-- Custom scripts -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.mainlayout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\PUTRAKENAKA\Downloads\Project_ExpertLingo-master\Project_ExpertLingo-master\resources\views/frontpage/pilih_guru.blade.php ENDPATH**/ ?>