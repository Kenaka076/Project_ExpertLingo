@extends('layouts.layout')
@section('content')
<body>
    sssssss
</body>

@endsection